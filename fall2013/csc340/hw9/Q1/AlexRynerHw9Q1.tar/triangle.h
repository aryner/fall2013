#include "figure.h"

class Triangle: public Figure
{
	public:
		Triangle();

		void draw();
		void erase();
};
