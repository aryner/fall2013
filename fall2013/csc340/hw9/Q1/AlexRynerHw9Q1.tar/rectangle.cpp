#include "rectangle.h"

Rectangle::Rectangle()
{
}

void Rectangle::draw()
{
	cout << "Drawing a rectangle..." << endl;
}

void Rectangle::erase()
{
	cout << "Erasing this rectangle..." << endl;
}
