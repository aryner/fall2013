#include "figure.h"

class Rectangle: public Figure
{
	public:
		Rectangle();
	
		void draw();
		void erase();
};
