#include "triangle.h"

Triangle::Triangle()
{
}

void Triangle::draw()
{
	cout << "A triangle is being drawn..." << endl;
}

void Triangle::erase()
{
	cout << "This triangle is being erased..." << endl;
}
